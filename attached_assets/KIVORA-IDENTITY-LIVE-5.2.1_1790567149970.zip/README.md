# Kivora 5.2.1 — Production-ready visual/product phase

This package is a **deploy-ready Kivora frontend/product pass** intended to be applied to the existing GitHub/Cloudflare project.

It deliberately does not require BitcoTasks credentials to build or preview. The provider remains a `NOT_CONFIGURED` runtime state until the later manual onboarding.

### Production target
`https://kivora-rewards.pages.dev/`

### Source
`https://github.com/grandmaster68081-byte/Vexforge-web.git`

### Scope
- Premium cinematic station experience
- Command Deck / Opportunity Field / Vault / Chronicle / Settlement Terminal
- Real Kivora/React integration with existing APIs
- USDT/TRC20 withdrawal contract
- 10,000 KP minimum
- provider-optional build/runtime state
- no BitcoTasks credentials in the package

### Build
Cloudflare Pages should install dependencies from `package.json` and run:

`npm run build`

This package intentionally does **not** require a new `package-lock.json`, so Cloudflare/Replit should use `npm install`, not `npm ci`.

## Verification note
The package was statically verified in this execution environment with the included Node contract test and secret scan. A complete Vite/TypeScript build could not be run here because the sandbox has no network access and no npm package cache; the package therefore avoids a new lockfile requirement and uses standard Cloudflare/Replit `npm install` behavior.

## Production visual identity
The files under `faucet/public/kivora/identity/` are production assets consumed by the live scene system. They are not documentation-only references. The active scene renderer points directly at the identity backplates for Command Deck, Opportunity Field, Kivora Vault, Chronicle, and Settlement Terminal.
