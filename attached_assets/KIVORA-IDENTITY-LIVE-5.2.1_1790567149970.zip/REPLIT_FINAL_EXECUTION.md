# KIVORA 5.2.1 — FINAL DIRECT EXECUTION ORDER

Realiza exactamente está implementación y no dejes el trabajo en ningún entorno local , todo el trabajo realizado debe quedar reflejado aquí https://kivora-rewards.pages.dev/

URL Github: https://github.com/grandmaster68081-byte/Vexforge-web.git

Supabase URL : https://rscuzqnfccqvltkdcdny.supabase.co

Para q realices el trabajo sin ninguna traba , pídeme las Pat de estás URL para q no te detengas al realizar la implementación q te exijo, no uses conectores para esto

## Scope lock

Execute the package as the source of truth. Do not invent, redesign, reinterpret, or substitute the visual system. Do not change VEXFORGE areas outside `faucet/` and the explicitly required Kivora assets/functions.

## Production visual identity — mandatory

The identity files in `faucet/public/kivora/identity/` are production assets, not references. The application MUST render them directly:

- `hero-environment.webp`
- `field-environment.webp`
- `vault-environment.webp`
- `chronicle-environment.webp`
- `settlement-environment.webp`
- `mobile-atlas.webp`
- `identity-master.webp`

`src/kivora/KivoraFinalWorld.tsx` MUST continue to consume the five scene paths above. Do not replace them with gradients, placeholders, generic CSS art, or alternative AI-generated assets.

## Product identity

The product must visually read as a premium game-inspired rewards station:

Command Deck → Opportunity Field → Vault → Chronicle → Settlement Terminal.

The Kivora Engine is the primary object. The scene environment is visible behind/around the functional UI. The visual identity must remain cinematic, dark, metallic, arcane/sci-fi, and VEXFORGE-compatible.

A generic dashboard with rounded cards and gradients is a failure condition.

## Functional preservation

Preserve existing Kivora integrations and contracts:

- Supabase auth/session
- wallet
- ledger/activity
- admin
- USDT/TRC20 withdrawal
- 10,000 KP minimum
- treasury metadata
- v2 RPC calls
- provider state

Do not replace the real APIs with mock data.

## BitcoTasks is NOT required yet

Do not request BitcoTasks credentials for this phase.

When credentials are absent:

- provider state = `NOT_CONFIGURED`
- build continues
- landing continues
- authenticated UI continues
- provider-dependent operations fail gracefully
- no fake rewards are generated

Do not put BitcoTasks secrets in source code, Git, frontend bundles, or static assets.

## Supabase DB password is NOT required for build

Do not add `SUPABASE_DB_PASSWORD` to Cloudflare runtime variables for this phase.

Only use the server-side Supabase runtime credentials already defined by the app when the Pages Functions need them.

## Build and deployment

Use:

```bash
npm install
npm run test
npm run typecheck
npm run build
```

Do NOT require `npm ci` because this package intentionally does not depend on a newly generated lockfile.

Deployment target:

- Cloudflare Pages project: `kivora-rewards`
- production branch: `main`
- root: `faucet`
- build command: `npm run build`
- output: `dist`
- production URL: `https://kivora-rewards.pages.dev/`

Do not create a second Pages project.
Do not create a parallel deployment path.

## Acceptance gate

Do not report DONE until all are true:

1. `npm install` succeeds.
2. `npm run test` succeeds.
3. `npm run typecheck` succeeds.
4. `npm run build` succeeds.
5. Cloudflare Pages deploys the new commit.
6. The production page renders the new Kivora identity assets.
7. Command Deck, Opportunity Field, Vault, Chronicle, and Settlement all render with their production identity backplates.
8. The provider remains `NOT_CONFIGURED` without BitcoTasks credentials.
9. No VEXFORGE files outside authorized Kivora scope were changed.

## Evidence required

Return:

- commit hash
- Cloudflare deployment identifier
- exact files changed
- test result
- typecheck result
- build result
- production URL
- provider state
- confirmation that the five identity assets are being served from production
- confirmation that BitcoTasks credentials were NOT required for this build
- confirmation that Supabase DB password was NOT added to Cloudflare runtime
