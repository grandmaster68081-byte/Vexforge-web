# Kivora 5.2.0 — Implementation Manifest

## Runtime changes
- New immersive `KivoraFinalWorld` with five persistent scenes.
- New landing experience with a cinematic station environment.
- Real data bindings to existing `/api/config`, `/api/offers`, `/api/account/wallet`, `/api/account/activity`, and `/api/withdraw` endpoints.
- Provider optional state (`providerConfigured=false`) without breaking navigation or build.
- USDT/TRC20-only withdrawal input contract.
- 10,000 KP minimum fallback.
- Treasury address fixed as public metadata fallback.

## Backend hardening included in this phase
- BitcoTasks environment credentials optional for build/runtime without provider.
- `public-config` reports `providerConfigured` instead of failing merely because the provider is not onboarded.
- Provider API helper exits cleanly with `BITCOTASKS_NOT_CONFIGURED` when absent.
- Withdrawal endpoint validates TRON Base58 and uses the v2 withdrawal RPC.
- Wallet/admin endpoints use v2 settlement/admin RPCs.
- BitcoTasks postback targets the v2 settlement RPC.

## Build contract
- No new package-lock is required by this phase.
- Use `npm install`, then `npm test`, `npm run typecheck`, `npm run build`.
- BitcoTasks credentials are not required for build.
- Supabase DB password is not required for build.

## Visual contract
- No card-dominant dashboard as the primary composition.
- Production scene backplates are real assets under `public/kivora/identity/` and are consumed directly by the renderer.
- World/background is persistent across scenes.
- Kivora Engine is the primary object.
- Opportunity Field is spatial and signal-based.
- Vault, Chronicle, and Settlement are distinct scenes.
- Motion communicates state and respects reduced motion.

## Build dependency hardening
- Explicit `lightningcss` devDependency is included for the Vite production CSS minifier.
- Use `npm install`, never `npm ci`, because this handoff intentionally does not ship a lockfile.
