# KIVORA 5.2.1 — DIRECT EXECUTION

Realiza exactamente esta implementación y no dejes el trabajo en ningún entorno local; todo el trabajo realizado debe quedar reflejado aquí:
https://kivora-rewards.pages.dev/

GitHub:
https://github.com/grandmaster68081-byte/Vexforge-web.git

Supabase URL:
https://rscuzqnfccqvltkdcdny.supabase.co

## Role
Replit es ejecutor. No rediseña, no cambia la visión y no inventa arquitectura.

## Scope
Only `faucet/` and files required by Kivora deployment. Do not touch VEXFORGE (`unity/`, `mobile/`, historical `src/`, historical `public/`, game contracts or backend outside Kivora).

## Apply
Copy/merge the 5.2.1 `faucet/` implementation into the repository preserving existing working server/API contracts.

## Provider decoupling
BitcoTasks remains optional for this phase. Do NOT request or add:
- BITCOTASKS_API_KEY
- BITCOTASKS_BEARER_TOKEN
- BITCOTASKS_SECRET_KEY
- BitcoTasks postback production credentials

The UI must display `PROVIDER NOT CONFIGURED` when absent and continue to build/deploy.

## Supabase
Use the existing server-side Supabase runtime secret only where Kivora Functions need it. `SUPABASE_DB_PASSWORD` is NOT a Cloudflare Pages runtime variable and is NOT required for build/deploy.

## Product contract
- 1000 KP = $1 display reference.
- Withdrawal minimum = 10,000 KP.
- Initial payout rail = USDT / TRC20.
- Treasury public address = `TLAujgYmQAtFW6BZg4fVs1pUHx6vyX5SJD`.
- Never add or request private key/seed phrase.

## Visual product contract
Implement the actual five-space Living Reward Station experience, not a generic dashboard skin:
1. Command Deck — Kivora Engine is the visual anchor.
2. Opportunity Field — signals are spatial and visually differentiated.
3. Kivora Vault — value storage is the scene/object, not a generic card list.
4. Chronicle — user activity reads as a visual journey.
5. Settlement Terminal — withdrawal is staged as a real process.

Use the supplied Kivora assets and the approved reference boards as visual authority. Do not replace the visual direction with generic SaaS/Web3 cards, gradients, glassmorphism or newly invented branding.

## Build/deploy
Use:
```bash
npm install
npm run verify
npm run typecheck
npm test
npm run build
```

Cloudflare Pages:
- project: `kivora-rewards`
- production branch: `main`
- root: `faucet`
- build: `npm run build`
- output: `dist`

## Evidence required before DONE
Return:
- git commit hash
- files changed
- `npm run verify` result
- `npm run typecheck` result
- `npm test` result
- `npm run build` result
- Cloudflare deployment id/commit
- production URL
- provider state (`NOT_CONFIGURED` is correct at this stage)

Do not declare success without a successful build and deployment.
